package co.edu.uniquindio.poo;

public enum TipoConsulta {
    GENERAL,
    QUIRURGICA,
    ESPECIALIDAD,

    
}
