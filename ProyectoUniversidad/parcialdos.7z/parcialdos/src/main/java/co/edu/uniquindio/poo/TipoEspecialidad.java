package co.edu.uniquindio.poo;

public enum TipoEspecialidad {
    CARDIOLOGIA,
    NEUROLOGIA,
    
}
