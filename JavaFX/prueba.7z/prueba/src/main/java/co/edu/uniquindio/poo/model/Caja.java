package co.edu.uniquindio.poo.model;

public enum Caja {
    AUTOMATICA,
    MANUAL
}
