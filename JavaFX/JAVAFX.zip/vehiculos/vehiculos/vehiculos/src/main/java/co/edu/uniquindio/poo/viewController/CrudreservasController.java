package co.edu.uniquindio.poo.viewController;

import java.time.LocalDate;
import java.net.URL;
import java.util.ResourceBundle;

import co.edu.uniquindio.poo.model.Cliente;
import co.edu.uniquindio.poo.model.Empresa;
import co.edu.uniquindio.poo.model.Reserva;
import co.edu.uniquindio.poo.model.Vehiculo;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public class CrudreservasController {

    @FXML // ResourceBundle that was given to the FXMLLoader
    private ResourceBundle resources;

    @FXML // URL location of the FXML file that was given to the FXMLLoader
    private URL location;

    @FXML // fx:id="fechainicio"
    private DatePicker fechainicio; // Value injected by FXMLLoader

    @FXML // fx:id="Fechafin"
    private DatePicker Fechafin; // Value injected by FXMLLoader

    @FXML // fx:id="costoCalculado"
    private TextField costoCalculado; // Value injected by FXMLLoader

    @FXML // fx:id="seleccionarCliente"
    private ChoiceBox<Cliente> seleccionarCliente; // Value injected by FXMLLoader

    @FXML // fx:id="listareservas"
    private TableView<Reserva> listareservas; // Value injected by FXMLLoader

    @FXML // fx:id="seleccionarVehiculo"
    private ChoiceBox<Vehiculo> seleccionarVehiculo; // Value injected by FXMLLoader

    private Empresa empresa; // Instancia de la empresa

    // Método para configurar la empresa y cargar clientes y vehículos en los ChoiceBox
    @SuppressWarnings("exports")
    public void setEmpresa(Empresa empresa) {
        this.empresa = empresa;
        cargarClientes();  // Cargar clientes en el ChoiceBox
        cargarVehiculos();  // Cargar vehículos en el ChoiceBox
    }

    // Cargar los clientes en el ChoiceBox
    private void cargarClientes() {
        if (empresa != null && empresa.getClientes() != null) {
            seleccionarCliente.getItems().clear();  // Limpiar los elementos anteriores
            seleccionarCliente.getItems().addAll(empresa.getClientes());  // Agregar nuevos clientes
        }
    }

    // Cargar los vehículos en el ChoiceBox
    private void cargarVehiculos() {
        if (empresa != null && empresa.getVehiculos() != null) {
            seleccionarVehiculo.getItems().clear();  // Limpiar los elementos anteriores
            seleccionarVehiculo.getItems().addAll(empresa.getVehiculos());  // Agregar nuevos vehículos
        }
    }

    // Acción para calcular el costo de la reserva
    @FXML
    void CalcularCosto(ActionEvent event) {
        LocalDate inicio = fechainicio.getValue();
        LocalDate fin = Fechafin.getValue();
        if (inicio != null && fin != null) {
            int diasReserva = (int) (java.time.Duration.between(inicio.atStartOfDay(), fin.atStartOfDay()).toDays());
            Vehiculo vehiculo = seleccionarVehiculo.getValue();
            if (vehiculo != null) {
                double costo = vehiculo.calcularCostoReserva(diasReserva);
                costoCalculado.setText(String.valueOf(costo));
            }
        }
    }

    // Acción para agregar una nueva reserva
    @FXML
    void agregarReserva(ActionEvent event) {
        LocalDate inicio = fechainicio.getValue();
        LocalDate fin = Fechafin.getValue();
        Cliente cliente = seleccionarCliente.getValue();
        Vehiculo vehiculo = seleccionarVehiculo.getValue();

        if (inicio != null && fin != null && cliente != null && vehiculo != null) {
            int diasReserva = (int) (java.time.Duration.between(inicio.atStartOfDay(), fin.atStartOfDay()).toDays());
            Reserva nuevaReserva = new Reserva(vehiculo, cliente, diasReserva);
            empresa.agregarReserva(nuevaReserva);
            // Actualizar la tabla de reservas
            listareservas.getItems().add(nuevaReserva);
        }
    }

    // Acción para actualizar una reserva existente
    @FXML
    void actualizarReserva(ActionEvent event) {
        // Lógica para actualizar la reserva seleccionada
        // Aquí deberías obtener la reserva seleccionada de la tabla y actualizarla
    }

    // Acción para eliminar una reserva
    @FXML
    void eliminarReserva(ActionEvent event) {
        Reserva reservaSeleccionada = listareservas.getSelectionModel().getSelectedItem();
        if (reservaSeleccionada != null) {
            empresa.eliminarReserva(reservaSeleccionada);
            listareservas.getItems().remove(reservaSeleccionada);
        }
    }

    @FXML // This method is called by the FXMLLoader when initialization is complete
    void initialize() {
        assert fechainicio != null : "fx:id=\"fechainicio\" was not injected: check your FXML file 'CrudReservas.fxml'.";
        assert Fechafin != null : "fx:id=\"Fechafin\" was not injected: check your FXML file 'CrudReservas.fxml'.";
        assert costoCalculado != null : "fx:id=\"costoCalculado\" was not injected: check your FXML file 'CrudReservas.fxml'.";
        assert seleccionarCliente != null : "fx:id=\"seleccionarCliente\" was not injected: check your FXML file 'CrudReservas.fxml'.";
        assert listareservas != null : "fx:id=\"listareservas\" was not injected: check your FXML file 'CrudReservas.fxml'.";
        assert seleccionarVehiculo != null : "fx:id=\"seleccionarVehiculo\" was not injected: check your FXML file 'CrudReservas.fxml'.";
    }
}
