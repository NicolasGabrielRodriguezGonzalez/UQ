package co.edu.uniquindio.poo.model;

public enum TipoCaja {
    AUTOMATICA,
    MANUAL
    
}
