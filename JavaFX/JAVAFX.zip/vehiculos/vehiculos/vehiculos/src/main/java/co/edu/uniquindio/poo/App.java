package co.edu.uniquindio.poo;

import co.edu.uniquindio.poo.model.Cliente;
import co.edu.uniquindio.poo.model.Empresa;
import co.edu.uniquindio.poo.model.Moto;
import co.edu.uniquindio.poo.model.TipoCaja;  // Importar el enum
import co.edu.uniquindio.poo.model.Auto;
import co.edu.uniquindio.poo.model.Camioneta;
import co.edu.uniquindio.poo.model.Vehiculo;
import co.edu.uniquindio.poo.viewController.CrudreservasController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class App extends Application {

    @Override
    public void start(Stage primaryStage) {
        try {
            // Crear algunos clientes
            Cliente cliente1 = new Cliente("Juan Perez");
            Cliente cliente2 = new Cliente("Ana Gómez");

            // Crear algunos vehículos
            Vehiculo vehiculo1 = new Auto("ABC123", "Toyota", "Corolla", "2020", 4, 40000);
            Vehiculo vehiculo2 = new Moto("MOTO001", "Yamaha", "YZF-R1", "2023", TipoCaja.AUTOMATICA, 20000);  // Corregido aquí
            Vehiculo vehiculo3 = new Camioneta("XYZ789", "Ford", "Ranger", "2022", 1000, 60000, 0.1);

            // Crear la empresa y agregar los clientes y vehículos
            Empresa empresa = new Empresa("Autos S.A");
            empresa.getClientes().add(cliente1);
            empresa.getClientes().add(cliente2);
            empresa.getVehiculos().add(vehiculo1);
            empresa.getVehiculos().add(vehiculo2);
            empresa.getVehiculos().add(vehiculo3);  // Agregar todos los vehículos

            // Cargar la interfaz principal desde el archivo FXML
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/co/edu/uniquindio/poo/CrudReservas.fxml"));
            Parent root = loader.load();  // Cargar la interfaz FXML

            // Obtener el controlador de la vista
            CrudreservasController controller = loader.getController();

            // Enviar la empresa al controlador
            controller.setEmpresa(empresa);

            // Configurar el escenario principal
            primaryStage.setTitle("Sistema de Alquiler de Vehículos");
            primaryStage.setScene(new Scene(root));
            primaryStage.setResizable(false);
            primaryStage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
