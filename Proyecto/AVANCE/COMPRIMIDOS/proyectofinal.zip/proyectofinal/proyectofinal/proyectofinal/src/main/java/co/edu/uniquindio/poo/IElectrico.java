package co.edu.uniquindio.poo;

public interface IElectrico {
    public String obtenerAutonomia();
    public String obtenerTiempoPromedio();

    
}
