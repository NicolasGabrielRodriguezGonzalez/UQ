package co.edu.uniquindio.poo;

public interface IHibrido {
     public String determinarEnchufableHibridoLigero();
}
