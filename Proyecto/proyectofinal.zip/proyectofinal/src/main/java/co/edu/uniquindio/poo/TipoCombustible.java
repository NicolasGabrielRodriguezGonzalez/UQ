package co.edu.uniquindio.poo;

public enum TipoCombustible {
    GASOLINA,
    DIESEL,
}
